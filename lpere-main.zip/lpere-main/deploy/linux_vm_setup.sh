#!/usr/bin/env bash
# ALgpt'yi herhangi bir Ubuntu sunucuda (örn. Oracle Cloud "Always Free" VM) her gün çalıştırır.
# Kullanım (sunucuda):  bash deploy/linux_vm_setup.sh
# Önce repo klasöründe .env dosyasını oluştur (TELEGRAM_*, CANDIDATE_*, STATE_KEY).
set -euo pipefail
cd "$(dirname "$0")/.."
APP_DIR="$(pwd)"

sudo apt-get update -qq
sudo apt-get install -y -qq python3 python3-venv xvfb fonts-dejavu-core wget
if ! command -v google-chrome >/dev/null; then
  ARCH="$(dpkg --print-architecture)"
  if [ "$ARCH" = "amd64" ]; then
    wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -O /tmp/chrome.deb
    sudo apt-get install -y -qq /tmp/chrome.deb
  else
    echo "ARM sunucu: Google Chrome yok, patchright'ın Chromium'u kurulacak (BROWSER_CHANNEL=chromium)."
    grep -q '^BROWSER_CHANNEL=' .env || echo 'BROWSER_CHANNEL=chromium' >> .env
  fi
fi

python3 -m venv .venv
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt
.venv/bin/python -m patchright install --with-deps chromium

mkdir -p logs
CRON="17 6 * * * cd $APP_DIR && xvfb-run -a --server-args='-screen 0 1366x900x24' .venv/bin/python main.py >> logs/run.log 2>&1"
( crontab -l 2>/dev/null | grep -v 'main.py' ; echo "$CRON" ) | crontab -
echo "Kuruldu. Her gün 06:17'de çalışacak (sunucu saatine göre). Elle test: xvfb-run -a .venv/bin/python main.py --dry-run --max-minutes 5"
